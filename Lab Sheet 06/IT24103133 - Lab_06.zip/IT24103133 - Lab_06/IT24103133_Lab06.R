getwd()
setwd("C:\\Users\\Asus\\Desktop\\IT24103133 - Lab_06")
getwd()

n <- 44; p <- 0.92

dbinom(40, size=44, prob=0.92)

pbinom(35, size=44, prob=0.92)

1 - pbinom(37, size=44, prob=0.92)

sum(dbinom(40:42, size=44, prob=0.92))



lambda <- 5

dpois(6, lambda=5)

1 - ppois(6, lambda=5)



n <- 50; p <- 0.85

1 - pbinom(46, size=50, prob=0.85)


lambda <- 12

dpois(15, lambda=12)
